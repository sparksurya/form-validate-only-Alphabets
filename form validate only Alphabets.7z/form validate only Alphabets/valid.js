function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}

function validateForm() {

    var name = document.Form.name.value;
    var password = document.Form.password.value;
    
    

    var nameErr = passwordErr  = true;
    

    if(name == "") {
        printError("nameErr", "Please enter your name");
        var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    } else {
        var regex = /^[a-zA-Z\s]+$/;                
        if(regex.test(name) === false) {
            printError("nameErr", "Please enter a valid name");
            var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("nameErr", "");
            nameErr = false;
            var elem = document.getElementById("name");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");

            
        }
    }
    

    if(password == "") {
        printError("passwordErr", "Please enter a valid password ");
         var elem = document.getElementById("password");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
    } else {
        
        var regex = /^[A-Za-z]+$/;
        if(regex.test(password) === false) {
            printError("passwordErr", "Please enter a valid password ");
            var elem = document.getElementById("password");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else{
            printError("passwordErr", "");
            passwordErr = false;
             var elem = document.getElementById("password");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");

        }
    }
    
  if((nameErr || passwordErr ) == true) {
       return false;
    } 
};